import { News } from './news.model';

describe('News', () => {
  it('should create an instance', () => {
    expect(new News()).toBeTruthy();
  });
});
