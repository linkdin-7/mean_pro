export class Donations {
    _id?: string;
    name:string;
    email: string;
    Date: string;
    description: string;
    item:String;
    quantity:number;
    address:String;
    phone:String;
    donation_by: String;
}