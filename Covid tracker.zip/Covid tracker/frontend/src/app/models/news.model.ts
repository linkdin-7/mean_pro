export class news {
    author : string;
    title : string
    description : string;
    url : string;
     urlImage : string;
     content : string;
}