import { Countrylmaodata } from './countrylmaodata.model';

describe('Countrylmaodata', () => {
  it('should create an instance', () => {
    expect(new Countrylmaodata()).toBeTruthy();
  });
});
