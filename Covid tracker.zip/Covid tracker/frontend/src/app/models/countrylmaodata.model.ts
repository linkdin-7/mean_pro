export class Countrylmaodata {
    country:string;
    cases : number;
    deaths : number;
    recovered : number;
    active : number;
    todayDeaths : number;
    critical : number;
    flag: string
}
