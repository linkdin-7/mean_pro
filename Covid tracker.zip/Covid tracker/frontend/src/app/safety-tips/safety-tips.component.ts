import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-safety-tips',
  templateUrl: './safety-tips.component.html',
  styleUrls: ['./safety-tips.component.scss']
})
export class SafetyTipsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
