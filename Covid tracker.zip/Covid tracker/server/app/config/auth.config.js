/**
 * This key is exported to the controller and used as a secret key.
 */
module.exports = {
    secret: "secret-key"
  };