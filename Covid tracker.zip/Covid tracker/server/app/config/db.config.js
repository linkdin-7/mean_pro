/**
 * Database and port information that is exported in the server.js
 */

module.exports = {
    HOST: "localhost",
    PORT: 27017,
    DB: "project1"
  };